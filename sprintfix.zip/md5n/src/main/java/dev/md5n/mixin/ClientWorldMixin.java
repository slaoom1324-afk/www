package dev.md5n.mixin;

import dev.md5n.Md5n;
import dev.md5n.module.modules.Sky;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientWorld.class)
public class ClientWorldMixin {

    // اللعبة تسأل هذي الدالة عن لون السماء كل فريم؛ نبدّل النتيجة إذا Sky مشغّل
    @Inject(method = "getSkyColor", at = @At("RETURN"), cancellable = true, require = 0)
    private void md5n$skyColor(Vec3d cameraPos, float tickDelta, CallbackInfoReturnable<Vec3d> cir) {
        if (Md5n.modules == null) return;
        Sky sky = Md5n.modules.get(Sky.class);
        if (sky == null || !sky.isEnabled()) return;

        Object original = cir.getReturnValue();
        if (!(original instanceof Vec3d base)) return;
        cir.setReturnValue(sky.apply(base));
    }
}
