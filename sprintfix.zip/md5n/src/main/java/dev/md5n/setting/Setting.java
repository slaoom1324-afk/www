package dev.md5n.setting;

import com.google.gson.JsonElement;

public abstract class Setting {
    public final String name;
    public final String description;
    private int key = -1;        // مفتاح لهذا الخيار (-1 = بدون)
    private boolean keyDown;

    protected Setting(String name, String description) {
        this.name = name;
        this.description = description == null ? "" : description;
    }

    public abstract JsonElement toJson();

    public abstract void fromJson(JsonElement element);

    /** هل نقدر نربط لهذا الخيار مفتاح يغيّره؟ */
    public boolean keyable() { return false; }

    /** يُستدعى لما تضغط المفتاح المربوط. */
    public void onKey() {}

    public int getKey() { return key; }

    public void setKey(int key) { this.key = key; }

    public boolean isKeyDown() { return keyDown; }

    public void setKeyDown(boolean down) { this.keyDown = down; }
}
